#include <stdio.h>
#include <string.h>
#include <stdlib.h> //  stdlib.h is used for system("cls") so that screen can be clear 
#include <conio.h>
// Structure is defined  to store user data to create account 
struct user 
{
    char fname[20];
    char lname[20];
    char fathname[20];
    char mothname[20];
    char address[50];
    char typeaccount[20];
    int date, month, year;
    char cnic[20];
    char pnumber[15];
    char username[20];
    char password[20];
    long int balance; // long data type is used beacuse balance can be greater than usual 2 or 3 digits number
};
// Structure is used keep data or memory of amount transfer
struct money
 {
    char usernameto[20];
    char userpersonfrom[20];
    long int money1;
};// Array to store user data during program execution
struct user users[100];
int userCount= 0;
// Function declarations
void createAccount(void);
void transferMoney(void);
void checkBalance(char username[]);
void depositMoney(char username[]);
void login(void);
void display(char username[]);
void logout(void);
int main() {
    int choice;
    do 
	{
        system("cls"); // this function is used through library stdlib to clear screen
        printf("WELCOME TO BANK ACCOUNT SYSTEM\n\n");
        printf("**********************************\n");
        printf("DEVELOPER    -		Shaheer KHAN\n\n");

        printf("1.... CREATE A BANK ACCOUNT\n\n");
        printf("2.... ALREADY A USER? SIGN IN\n\n");
    
        printf("3.... EXIT\n\n\n");

        printf("\n\nENTER YOUR CHOICE..");
        scanf("%d", &choice);
        switch (choice)
		 {
            case 1:
                createAccount();
                break;
            case 2:
                login();
                break;
            case 3:
                exit(0);
                break;
            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    } 
	while(1);
    return 0;
}
void createAccount(void) 
{
    struct user u1;
    system("cls"); // Clear screen
    printf("\n\n!!!!!CREATE ACCOUNT!!!!!");
    printf("\n\nFIRST NAME: ");
    scanf("%s", &u1.fname);
    printf("\n\n\nLAST NAME: ");
    scanf("%s", &u1.lname);
    printf("\n\nADDRESS: ");
    scanf("%s", &u1.address);
    printf("\n\nACCOUNT TYPE: ");
    scanf("%s", u1.typeaccount);
    printf("\n\nDATE OF BIRTH: ");
    printf("\nDATE- ");
    scanf("%d", &u1.date);
    printf("\nMONTH- ");
    scanf("%d", &u1.month);
    printf("\nYEAR- ");
    scanf("%d", &u1.year);
    printf("\n\nCnic NUMBER: ");
    scanf("%s", u1.cnic);
    printf("\n\nPHONE NUMBER: ");
    scanf("%s", u1.pnumber);
    printf("\n\nUSERNAME: ");
    scanf("%s", u1.username);
    printf("\n\nPASSWORD: ");
    // Taking password in the form of stars
    int i = 0;
    while(1)
	 {
        u1.password[i] =getch(); //getch is used beacuse in scanf input cannot be takken in spaces
        if (u1.password[i]== 13 || u1.password[i]== 10)
		 { // Stop taking input on Enter key
            break;     }
	 else if(i>0 || u1.password[i]!='\b') 
 { // //\b refers to backspace 
            printf("*");
            i++;
  }
  }
    u1.password[i] = '\0'; // Nullterminate the password
    u1.balance = 0; // Set initial balance to 0
    users[userCount++] = u1; // Add user to the array who create the account  
    display(u1.username);
}
void login(void) 
{
    char username[20];
    char password[20];
    system("cls"); 
    printf(" ACCOUNT LOGIN \n");
    printf("************************************************\n\n");
    printf("==== LOG IN ====\n");
    printf("USERNAME.. ");
    scanf("%s", &username);
    printf("PASSWORD..");
    // Input the password in term of *
    int i = 0;
    while (1) 
	{
        password[i] = getch();
        if (password[i] == 13 || password[i] == 10)
		 { // Stop taking input on Enter key
            break;
        }
		 else if(i>0 || password[i]!='\b')
		  { // Check for backspace
            printf("*");
            i++;
        }}
    password[i] = '\0'; // Null-terminate the password
    // Check if the username and password match if not it will display incorrect password
    int userIndex=-1;
    for(int i=0;i<userCount;i++)
{
 if(strcmp(username, users[i].username)==0 && strcmp(password,users[i].password)== 0) 
    {
        userIndex= i;
        break;
    }}
    if(userIndex!= -1) 
	{
        display(username);
    } 
	else 
	 {
        printf("\nInvalid username or password. Please try again.\n");
    }
}
void display(char username[]) 
{
    int choice;
    do {
        system("cls"); // Clear screen
        printf("Welcome, %s\n", username);

        printf("\n1....CHECK BALANCE");
        printf("\n2....TRANSFER MONEY");
        printf("\n3....DEPOSIT MONEY");
        printf("\n4....LOG OUT\n");
        printf("\n5....EXIT\n");
        printf("\nEnter your choice..");
        scanf("%d", &choice);
        switch (choice) 
		
		{
            case 1:
                checkBalance(username);
                break;
    case 2:
                transferMoney();
                break;
     case 3:
                depositMoney(username);
                break;

    case 4:
                logout();
                break;
  case 5:
                exit(0);
                break;
default:
                printf("\nInvalid choice. Please try again.\n");
        }
  /*Consume newline character left in input buffer means if we use scanf() it will take an input but when we give it 2nd input it can be mess up with 1st one 
        so scanf("%*c) is used which clear the old input tp prevent that issue*/ 
        scanf("%*c");


    } 
	while (1);
}
void checkBalance(char username[])
{
    system("cls"); // Clear screen
    int userIndex = -1;
    for(int i=0; i<userCount; i++)
{ if (strcmp(username, users[i].username) == 0)
        {
            userIndex = i;
            break;
 }
    }
    if (userIndex!=-1)
    {
        printf("Welcome, %s\n", username);
        long int *balancePtr = &users[userIndex].balance; // Pointer is used to point user balance
        printf("Your balance: %ld\n", *balancePtr); // Accessing balance using pointer
    }
    else
    {
        printf("User not found. Please try again.\n");
    }
    printf("Press enter to continue...");
    getchar(); // Wait for the user to press enter
}

void depositMoney(char username[]) 
{
    int userIndex=-1;
    long int amount;
    printf("Enter the amount to deposit: ");
    scanf("%ld", &amount);
    for(int i=0;i<userCount;i++) 
	{
        if (strcmp(username, users[i].username)== 0) 
		{
            userIndex=i;
            break;
        }
    }
    if (userIndex!= -1) 
	{
        users[userIndex].balance += amount;
        printf("Deposit successful. New balance: %ld\n",users[userIndex].balance);
    } else 
	{
        printf("User not found. Please try again.\n");
    }
    printf("Press enter to continue...");
    getchar(); // Wait for user to press enter
}

void transferMoney(void) 
{
    struct money m1;
    char usernamet[20];
    char usernamep[20];

    system("cls"); // Clear screen
    printf("---- TRANSFER MONEY ----\n");
    printf("========================\n");
    printf("FROM (your username).. ");
    scanf("%s", usernamet);
    printf("TO (username of person)..");
    scanf("%s", usernamep);
    // Checking for usernames in the array
    int fromIndex=-1,toIndex= -1;
    for(int i=0; i<userCount;i++){
        if(strcmp(usernamet, users[i].username)==0) 
		{
            fromIndex = i;
        }
        if(strcmp(usernamep, users[i].username) == 0)
		 {
            toIndex = i;
        }
    }
    if (fromIndex != -1 && toIndex != -1) 
	{
        strcpy(m1.usernameto, users[toIndex].username);
        strcpy(m1.userpersonfrom, users[fromIndex].username);
        printf("ENTER THE AMOUNT TO BE TRANSFERRED..");
        scanf("%ld", &m1.money1);
        // transfering the money to other acc
        if (m1.money1 <= users[fromIndex].balance) 
		{
            users[fromIndex].balance -= m1.money1;
            users[toIndex].balance += m1.money1;
            printf("Amount successfully transferred.\n");
        } else 
		{
            printf("Insufficient funds.\n");
        }
    } 
	else
	 {
        printf("Invalid usernames. Please try again.\n");
    }
    printf("Press enter to continue...");
    getchar(); // Wait for user to press enter
}

void logout(void) 
{
    printf("Logging out...\n");
    printf("Press enter to continue...");
    getchar(); // Wait for user to press enter
    main(); // Restart the main loop
}
